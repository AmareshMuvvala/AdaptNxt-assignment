import styles from "./index.css";

import React from "react";

const Dashboard = () => {
  return <div className={styles.Dashboard}></div>;
};

export default Dashboard;
